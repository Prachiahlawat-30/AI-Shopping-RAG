import api from "./api";

export async function chat(
  question: string,
  history: any[]
) {
  const response = await api.post("/ai-chat", {
    question,
    history,
  });

  return response.data;
}
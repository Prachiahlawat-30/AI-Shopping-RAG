import { api } from "./api";

import {
  SearchRequest,
  SearchResponse,
  SimilarProductsResponse,
  SearchSuggestionsResponse,
  SearchHistoryResponse,
} from "@/types/search";

class SearchService {
  /**
   * Semantic Search
   */
  async search(
    request: SearchRequest
  ): Promise<SearchResponse> {
    const { data } = await api.post<SearchResponse>(
      "/search/text",
      request
    );

    return data;
  }

  /**
   * Image Search
   */
  async imageSearch(
    image: File,
    limit = 20
  ): Promise<SearchResponse> {
    const formData = new FormData();

    formData.append("image", image);

    const { data } =
      await api.post<SearchResponse>(
        `/search/image?limit=${limit}`,
        formData,
        {
          headers: {
            "Content-Type":
              "multipart/form-data",
          },
        }
      );

    return data;
  }

  /**
   * Similar Products
   */
  async getSimilarProducts(
    productId: number
  ): Promise<SimilarProductsResponse> {
    const { data } =
      await api.get<SimilarProductsResponse>(
        `/search/similar/${productId}`
      );

    return data;
  }

  /**
   * Search Suggestions
   */
  async getSuggestions(
    query: string
  ): Promise<SearchSuggestionsResponse> {
    const { data } =
      await api.get<SearchSuggestionsResponse>(
        "/search/suggestions",
        {
          params: {
            q: query,
          },
        }
      );

    return data;
  }

  /**
   * Search History
   */
  async getHistory(): Promise<SearchHistoryResponse> {
    const { data } =
      await api.get<SearchHistoryResponse>(
        "/search/history"
      );

    return data;
  }

  /**
   * Hybrid Search
   */
  async hybridSearch(
    query: string,
    image?: File,
    filters?: Record<string, unknown>
  ): Promise<SearchResponse> {
    const formData = new FormData();

    formData.append("query", query);

    if (image) {
      formData.append("image", image);
    }

    if (filters) {
      formData.append(
        "filters",
        JSON.stringify(filters)
      );
    }

    const { data } =
      await api.post<SearchResponse>(
        "/search/hybrid",
        formData,
        {
          headers: {
            "Content-Type":
              "multipart/form-data",
          },
        }
      );

    return data;
  }
}

export default new SearchService();
import React from 'react';
import { Upload, Search, Eye, MessageSquare } from 'lucide-react';

export const HistoryFilter: React.FC = () => {
  return (
    <div className="flex flex-wrap items-center gap-2">
      {/* Upload Filter */}
      <button className="flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-indigo-950/40 border border-indigo-500/30 text-indigo-300 text-xs font-medium hover:bg-indigo-900/40 transition-colors">
        <Upload className="w-3.5 h-3.5 text-indigo-400" />
        Upload
      </button>

      {/* Search Filter */}
      <button className="flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-purple-950/40 border border-purple-500/30 text-purple-300 text-xs font-medium hover:bg-purple-900/40 transition-colors">
        <Search className="w-3.5 h-3.5 text-purple-400" />
        Search
      </button>

      {/* Viewed Filter */}
      <button className="flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 text-xs font-medium hover:bg-emerald-900/40 transition-colors">
        <Eye className="w-3.5 h-3.5 text-emerald-400" />
        Viewed
      </button>

      {/* AI Chat Filter */}
      <button className="flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-amber-950/40 border border-amber-500/30 text-amber-300 text-xs font-medium hover:bg-amber-900/40 transition-colors">
        <MessageSquare className="w-3.5 h-3.5 text-amber-400" />
        AI Chat
      </button>
    </div>
  );
};
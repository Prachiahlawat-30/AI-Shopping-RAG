import React, { useState } from 'react';
import { Sparkles, Menu, X } from 'lucide-react';

interface HeaderProps {
  activeTab?: string;
  onTabChange?: (tab: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ 
  activeTab = 'Visual Search',
  onTabChange 
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = ['Home', 'Visual Search', 'Upload', 'History', 'AI Chat'];

  return (
    <header className="sticky top-0 z-50 w-full bg-[#08080c] border-b border-[#14141c]">
      <div className="w-full flex items-center justify-between px-6 py-4">
        
        {/* Brand Logo */}
        <div className="flex items-center gap-3 cursor-pointer">
          <div className="w-9 h-9 rounded-xl bg-[#635BFF] flex items-center justify-center text-white shadow-md">
            <Sparkles className="w-5 h-5 fill-white/20" />
          </div>
          <span className="font-bold text-white text-lg tracking-wide">
            AI Shopping RAG
          </span>
        </div>

        {/* Desktop Navigation Pill Bar */}
        <nav className="hidden md:flex items-center gap-1 bg-[#121218] p-1.5 rounded-full border border-[#1e1e28]">
          {navItems.map((item) => {
            const isActive = activeTab === item;
            return (
              <button
                key={item}
                onClick={() => onTabChange?.(item)}
                className={`
                  px-5 py-2 text-sm font-medium transition-all duration-200 cursor-pointer
                  ${
                    isActive
                      ? 'bg-[#23232b] text-white rounded-full font-semibold shadow-sm'
                      : 'text-zinc-400 hover:text-zinc-200 rounded-full'
                  }
                `}
              >
                {item}
              </button>
            );
          })}
        </nav>

        {/* Status Badge, Profile Avatar, & Mobile Menu */}
        <div className="flex items-center gap-4">
          {/* Live Status Badge */}
          <div className="hidden sm:flex items-center gap-2 px-3 py-1 rounded-full bg-[#051a11] border border-[#0f3822] text-[#22c55e] text-xs font-semibold">
            <span className="w-2 h-2 rounded-full bg-[#22c55e]" />
            Live
          </div>

          {/* User Avatar Circle */}
          <div className="w-9 h-9 rounded-full bg-[#5054f2] text-white font-bold flex items-center justify-center text-sm shadow-sm cursor-pointer">
            A
          </div>

          {/* Mobile Toggle */}
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-1 text-zinc-400 hover:text-white md:hidden transition-colors"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-[#1e1e28] bg-[#0d0d12] px-6 py-3 space-y-1">
          {navItems.map((item) => {
            const isActive = activeTab === item;
            return (
              <button
                key={item}
                onClick={() => {
                  onTabChange?.(item);
                  setMobileMenuOpen(false);
                }}
                className={`
                  w-full text-left px-4 py-2.5 rounded-lg text-sm font-medium transition-all
                  ${
                    isActive
                      ? 'bg-[#23232b] text-white font-semibold'
                      : 'text-zinc-400 hover:bg-[#16161f] hover:text-white'
                  }
                `}
              >
                {item}
              </button>
            );
          })}
        </div>
      )}
    </header>
  );
};
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):

    OPENAI_API_KEY: str

    MODEL_NAME: str = "gpt-5"

    DATABASE_URL: str

    QDRANT_URL: str

    QDRANT_API_KEY: str

    model_config = SettingsConfigDict(
        env_file=".env",
        extra="ignore",
    )


settings = Settings()
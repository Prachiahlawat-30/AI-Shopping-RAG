from app.database.database import Base, engine

# Import all models so SQLAlchemy knows about them
from app.database.models import Product

Base.metadata.create_all(bind=engine)

print("✅ Database tables created successfully.")
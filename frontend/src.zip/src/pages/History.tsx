import React from 'react';
import { Header } from '../components/history/Header';
import { HistoryFilter } from '../components/history/HistoryFilter';
import { HistoryItem, HistoryEvent } from '../components/history/HistoryItem';

const HISTORY_DATA: HistoryEvent[] = [
  {
    id: '1',
    type: 'upload',
    title: 'Uploaded Nike Air Max 270',
    subtitle: '4 images analyzed · 97% confidence',
    time: '2:34 PM',
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=150',
    tags: ['Footwear', 'Athletic', 'Nike'],
  },
  {
    id: '2',
    type: 'search',
    title: 'Searched "running shoes black mesh"',
    subtitle: '6 results · Top match: Nike Air Max 270 (94.7%)',
    time: '2:41 PM',
    tags: ['Semantic Search', 'Qdrant'],
  },
  {
    id: '3',
    type: 'chat',
    title: 'AI conversation — Nike Air Max',
    subtitle: '4 messages · Authenticity & material analysis',
    time: '2:50 PM',
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=150',
  },
];

export const HistoryPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-[#08080a] text-gray-200 flex flex-col font-sans">
      {/* Navigation Header */}
      <Header activeTab="History" />

      {/* Content Container */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-6 py-10">
        
        {/* Header Section */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 mb-10">
          <div>
            <span className="text-xs font-bold tracking-widest text-gray-500 uppercase mb-2 block">
              Activity Log
            </span>
            <h1 className="text-4xl sm:text-5xl font-extrabold text-white tracking-tight">
              Search History
            </h1>
          </div>

          {/* Type Filters */}
          <HistoryFilter />
        </div>

        {/* Timeline Group: Today */}
        <div className="relative">
          {/* Section Divider Header */}
          <div className="flex items-center justify-between mb-6">
            <span className="text-sm font-semibold text-gray-400">Today</span>
            <span className="text-xs text-gray-600 font-mono">
              {HISTORY_DATA.length} events
            </span>
          </div>

          {/* Timeline List */}
          <div className="flex flex-col gap-4">
            {HISTORY_DATA.map((event, index) => (
              <HistoryItem
                key={event.id}
                item={event}
                isLast={index === HISTORY_DATA.length - 1}
              />
            ))}
          </div>
        </div>

      </main>

      {/* Floating Action Button */}
      <div className="fixed bottom-6 right-6">
        <button className="w-10 h-10 rounded-xl bg-blue-600 hover:bg-blue-500 text-white flex items-center justify-center shadow-lg transition-colors">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
          </svg>
        </button>
      </div>
    </div>
  );
};
import axios from "axios";

/**
 * Axios instance for communicating with the FastAPI backend.
 */
export const api = axios.create({
  baseURL: (import.meta as any).env.VITE_API_URL || "http://localhost:8000",
  timeout: 60000, // 60 seconds
  headers: {
    Accept: "application/json",
  },
});

/**
 * Request Interceptor
 */
api.interceptors.request.use(
  (config) => {
    console.log(
      `🚀 ${config.method?.toUpperCase()} ${config.baseURL}${config.url}`
    );
    return config;
  },
  (error) => Promise.reject(error)
);

/**
 * Response Interceptor
 */
api.interceptors.response.use(
  (response) => response,
  (error) => {
    console.error("API Error:", error);

    return Promise.reject(
      error.response?.data || {
        message: "Something went wrong.",
      }
    );
  }
);
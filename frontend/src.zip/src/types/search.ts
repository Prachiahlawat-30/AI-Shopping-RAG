export interface SearchFilters {
  brands: string[];
  categories: string[];
  colors: string[];
  min_price?: number;
  max_price?: number;
}

export interface SearchRequest {
  query: string;
  page: number;
  limit: number;
  filters?: SearchFilters;
}

export interface SearchResult {
  id: number;

  product_name: string;

  brand: string;

  category: string;

  description: string;

  thumbnail?: string;

  price?: number;

  currency?: string;

  rating?: number;

  review_count?: number;

  availability?: string;

  similarity_score: number;
}

export interface SearchResponse {
  query: string;

  total: number;

  page: number;

  limit: number;

  results: SearchResult[];
}

export interface SimilarProductsResponse {
  products: SearchResult[];
}

export interface SearchSuggestionsResponse {
  suggestions: string[];
}

export interface SearchHistoryResponse {
  history: string[];
}
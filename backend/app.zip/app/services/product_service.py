import os
import shutil
from typing import List

from fastapi import HTTPException, UploadFile
from sqlalchemy.orm import Session

from app.database.models import Product
from app.repositories.product_repository import ProductRepository

from app.services.embedding import embedding_service
from app.services.fusion import MetadataFusionService
from app.services.vision import VisionService


UPLOAD_DIR = "uploads"

os.makedirs(
    UPLOAD_DIR,
    exist_ok=True,
)


ALLOWED_TYPES = {
    "image/jpeg",
    "image/png",
    "image/webp",
    "image/jpg",
}


class ProductService:

    @staticmethod
    async def create_product(
        db: Session,
        images: List[UploadFile],
    ) -> Product:

        saved_paths = []

        # ------------------------------------
        # Save Images
        # ------------------------------------

        for image in images:

            if image.content_type not in ALLOWED_TYPES:

                raise HTTPException(
                    status_code=400,
                    detail=f"{image.filename} is not supported.",
                )

            filepath = os.path.join(
                UPLOAD_DIR,
                image.filename,
            )

            with open(filepath, "wb") as buffer:

                shutil.copyfileobj(
                    image.file,
                    buffer,
                )

            saved_paths.append(filepath)

        # ------------------------------------
        # Vision Analysis
        # ------------------------------------

        products = VisionService.analyze_multiple_products(
            saved_paths
        )

        # ------------------------------------
        # Merge Metadata
        # ------------------------------------

        fused = MetadataFusionService.merge(
            products
        )

        # ------------------------------------
        # AI Search Metadata
        # ------------------------------------

        embedding_summary = (
            MetadataFusionService.create_embedding_summary(
                fused
            )
        )

        keywords = (
            MetadataFusionService.create_search_keywords(
                fused
            )
        )

        thumbnail = (
            MetadataFusionService.get_thumbnail(
                saved_paths
            )
        )

        shop = (
            MetadataFusionService.default_shop_metadata()
        )

        # ------------------------------------
        # Product Model
        # ------------------------------------

        product = Product(

            brand=fused.brand,

            product_name=fused.product_name,

            category=fused.category,

            model=fused.model,

            color=fused.color,

            material=fused.material,

            description=fused.description,

            features=fused.features,

            specifications=fused.specifications,

            image_paths=saved_paths,

            embedding_summary=embedding_summary,

            search_keywords=keywords,

            thumbnail=thumbnail,

            price=shop["price"],

            currency=shop["currency"],

            rating=shop["rating"],

            review_count=shop["review_count"],

            availability=shop["availability"],

            product_url=shop["product_url"],
        )

        # ------------------------------------
        # Save PostgreSQL
        # ------------------------------------

        product = ProductRepository.create(
            db=db,
            product=product,
        )

        # ------------------------------------
        # Store in Qdrant
        # ------------------------------------

        embedding_service.store_product(

            product_id=product.id,

            text=embedding_summary,

            metadata={

                "brand": product.brand,

                "product_name": product.product_name,

                "category": product.category,

                "color": product.color,

                "price": product.price,

            },

        )

        return (
    product,
    fused,
    products,
)
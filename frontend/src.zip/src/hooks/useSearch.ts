import { useMutation, useQuery } from "@tanstack/react-query";

import semanticSearch from "../services/SearchService";
import imageSearch from "../services/SearchService";
import getSimilarProducts from "../services/SearchService";
import getSuggestions from "../services/SearchService";
import getSearchHistory from "../services/SearchService";

import {
  SearchRequest,
  SearchResponse,
  SimilarProductsResponse,
  SearchSuggestionsResponse,
  SearchHistoryResponse,
} from "@/types/search";



// -----------------------------------------------------
// Semantic Search
// -----------------------------------------------------

export function useSemanticSearch() {
  return useMutation<SearchResponse, Error, SearchRequest>({
    mutationFn: semanticSearch,
  });
}


// -----------------------------------------------------
// Image Search
// -----------------------------------------------------

export function useImageSearch() {
  return useMutation<SearchResponse, Error, File>({
    mutationFn: (file) => imageSearch(file),
  });
}


// -----------------------------------------------------
// Similar Products
// -----------------------------------------------------

export function useSimilarProducts(productId?: number) {
  return useQuery<SimilarProductsResponse>({
    queryKey: ["similar-products", productId],
    queryFn: () => getSimilarProducts(productId!),
    enabled: !!productId,
  });
}


// -----------------------------------------------------
// Search Suggestions
// -----------------------------------------------------

export function useSearchSuggestions(query: string) {
  return useQuery<SearchSuggestionsResponse>({
    queryKey: ["search-suggestions", query],
    queryFn: () => getSuggestions(query),
    enabled: query.length > 1,
    staleTime: 1000 * 60 * 5,
  });
}


// -----------------------------------------------------
// Search History
// -----------------------------------------------------

export function useSearchHistory() {
  return useQuery<SearchHistoryResponse>({
    queryKey: ["search-history"],
    queryFn: getSearchHistory,
    staleTime: 1000 * 60 * 10,
  });
}
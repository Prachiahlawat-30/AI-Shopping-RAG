import { useState, useEffect } from "react";
import { Header } from "@/components/visualsearch/Header";
import { SearchInput } from "@/components/visualsearch/SearchInput";
import SuggestionPills from "@/components/visualsearch/SuggestionPills";
import { EmptyState } from "@/components/visualsearch/EmptyState";
import SearchFilters, { SearchFiltersValue } from "@/components/visualsearch/SearchFilters";
import SearchResults from "@/components/visualsearch/SearchResults";
import { useSemanticSearch } from "@/hooks/useSearch";

export function VisualSearchPage() {
  const [query, setQuery] = useState("");
  const [activeTab, setActiveTab] = useState("Visual Search");

  const [filters, setFilters] = useState<SearchFiltersValue>({
    brands: [],
    categories: [],
    colors: [],
    min_price: undefined,
    max_price: undefined,
  });

  const search = useSemanticSearch();

  // Execute Search Function
  const handleSearch = (searchText: string) => {
    setQuery(searchText);
    if (!searchText.trim()) return;

    search.mutate({
      query: searchText,
      page: 1,
      limit: 20,
      filters,
    });
  };

  // Trigger Image Visual Search (Direct file processing)
  const handleImageSearch = (file: File) => {
    console.log("Processing image for visual vector search:", file.name);
    const searchPrompt = `Visual Search: ${file.name}`;
    setQuery(searchPrompt);
    
    search.mutate({
      query: searchPrompt,
      page: 1,
      limit: 20,
      filters,
    });
  };

  // Automatically re-run search when filters update (if query exists)
  useEffect(() => {
    if (query && search.data) {
      search.mutate({
        query,
        page: 1,
        limit: 20,
        filters,
      });
    }
  }, [filters]);

  const hasSearchData = Boolean(search.data?.results && search.data.results.length > 0) || search.isPending;

  return (
    <div className="min-h-screen bg-[#09090b] text-zinc-100 font-sans antialiased selection:bg-indigo-500 selection:text-white">
      {/* Background Decorative Gradient Glow */}
      <div className="fixed top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-gradient-to-b from-indigo-900/10 via-purple-900/5 to-transparent blur-3xl pointer-events-none -z-10" />

      {/* Header placed OUTSIDE <main> so it spans 100% full width edge-to-edge */}
      <Header 
        activeTab={activeTab} 
        onTabChange={(tab) => setActiveTab(tab)} 
      />

      {/* Main Container with max-width constraint & horizontal padding */}
      <main className="mx-auto flex max-w-7xl flex-col gap-8 px-4 sm:px-6 py-8 sm:py-12">
        
        {/* Centralized Search Bar Container */}
        <section className="w-full max-w-3xl mx-auto flex flex-col items-center">
          <SearchInput
            value={query}
            onChange={(val) => setQuery(val)}
            onImageSelect={handleImageSearch}
          />

          {!hasSearchData && (
            <div className="w-full max-w-2xl">
              <SuggestionPills onSelect={handleSearch} />
            </div>
          )}
        </section>

        {/* Default View: Dropzone / Empty State */}
        {!hasSearchData && (
          <section className="w-full mt-4">
            <EmptyState onImageSelect={handleImageSearch} />
          </section>
        )}

        {/* Results View: Filters + Staggered Results Grid */}
        {hasSearchData && (
          <section className="grid gap-8 lg:grid-cols-[280px_1fr] items-start pt-4">
            <aside className="w-full">
              <SearchFilters filters={filters} onChange={setFilters} />
            </aside>
            <div className="w-full min-w-0">
              <SearchResults
                products={search.data?.results || []}
                loading={search.isPending}
              />
            </div>
          </section>
        )}
      </main>
    </div>
  );
}
import { Routes, Route } from "react-router-dom";
import MainLayout from "./layouts/MainLayout";
import Home from "./pages/Home";
import { UploadPage } from "./pages/Upload";
import { VisualSearchPage } from "./pages/VisualSearchPage";
import { HistoryPage } from "./pages/History";
import { AIChatPage } from "./pages/Chat";

function App() {
  return (
    <Routes>
      <Route element={<MainLayout />}>
        <Route index element={<Home />} />
        <Route path="upload" element={<UploadPage />} />
        <Route path="visual-search" element={<VisualSearchPage />} />
        <Route path="history" element={<HistoryPage />} />
        <Route path="ai-chat" element={<AIChatPage />} />
      </Route>
    </Routes>
  );
}

export default App;
import React from 'react';
import { Sparkles, Menu } from 'lucide-react';

interface HeaderProps {
  activeTab?: string;
}

export const Header: React.FC<HeaderProps> = ({ activeTab = 'History' }) => {
  const tabs = ['Home', 'Visual Search', 'Upload', 'History', 'AI Chat'];

  return (
    <header className="sticky top-0 z-50 flex items-center justify-between px-6 py-4 bg-[#08080a]/80 backdrop-blur-md border-b border-gray-900">
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl bg-indigo-600 flex items-center justify-center text-white shadow-lg shadow-indigo-500/20">
          <Sparkles className="w-5 h-5" />
        </div>
        <span className="font-bold text-white text-lg tracking-wide">
          AI Shopping RAG
        </span>
      </div>

      <nav className="hidden md:flex items-center gap-1 bg-[#121217] p-1.5 rounded-xl border border-gray-800/60">
        {tabs.map((tab) => {
          const isActive = tab === activeTab;
          return (
            <button
              key={tab}
              className={`px-4 py-2 text-sm transition-colors rounded-lg font-medium ${
                isActive
                  ? 'text-white bg-[#22222b] shadow-sm'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              {tab}
            </button>
          );
        })}
      </nav>

      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/40 border border-emerald-500/30 text-emerald-400 text-xs font-medium">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          Live
        </div>

        <div className="w-9 h-9 rounded-full bg-indigo-500 text-white font-semibold flex items-center justify-center text-sm shadow-md">
          A
        </div>

        <button className="p-1 text-gray-400 hover:text-white transition-colors">
          <Menu className="w-6 h-6" />
        </button>
      </div>
    </header>
  );
};
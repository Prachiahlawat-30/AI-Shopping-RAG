import React, { useState } from 'react';
import { Header } from '../components/chat/Header';
import { ChatSidebar, Conversation } from '../components/chat/ChatSidebar';
import { ChatMessage, Message } from '../components/chat/ChatMessage';
import { Bot, Send, PanelLeftClose, PanelLeft } from 'lucide-react';

const INITIAL_CONVERSATIONS: Conversation[] = [
  { id: '1', title: 'Nike Air Max authenticity', date: 'Today', active: true },
  { id: '2', title: 'Material comparison headphones', date: 'Today', active: false },
  { id: '3', title: 'Luxury bag alternatives', date: 'Yesterday', active: false },
  { id: '4', title: 'Sports shoe recommendations', date: '2 days ago', active: false },
];

const INITIAL_MESSAGES_MAP: Record<string, Message[]> = {
  '1': [
    {
      id: 'm1',
      sender: 'ai',
      text: "Hello! I'm your AI shopping assistant powered by GPT-5 and RAG.\n\nI have full context of your uploaded products, search history, and the Qdrant vector database. Ask me anything about your products — authenticity, materials, similar items, or comparisons.",
      timestamp: '09:56 am',
    },
  ],
  '2': [
    {
      id: 'm2',
      sender: 'ai',
      text: "Comparing materials for Sony WH-1000XM5 and Bose QuietComfort Ultra...",
      timestamp: '10:15 am',
    },
  ],
  '3': [
    {
      id: 'm3',
      sender: 'ai',
      text: "Here are top luxury leather bag alternatives under €2000.",
      timestamp: 'Yesterday',
    },
  ],
  '4': [
    {
      id: 'm4',
      sender: 'ai',
      text: "Recommendations based on air cushion technology in athletic shoes.",
      timestamp: '2 days ago',
    },
  ],
};

const SUGGESTIONS = [
  'Is this product original?',
  'What material is this made from?',
  'Find cheaper alternatives',
  'Compare with similar products',
];

export const AIChatPage: React.FC = () => {
  const [conversations, setConversations] = useState<Conversation[]>(INITIAL_CONVERSATIONS);
  const [messagesMap, setMessagesMap] = useState<Record<string, Message[]>>(INITIAL_MESSAGES_MAP);
  const [activeChatId, setActiveChatId] = useState<string>('1');
  const [inputText, setInputText] = useState('');
  
  // 1. Sidebar Open/Close Toggle State
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(true);

  // Switch Active Conversation
  const handleSelectConversation = (id: string) => {
    setActiveChatId(id);
    setConversations((prev) =>
      prev.map((c) => ({
        ...c,
        active: c.id === id,
      }))
    );
  };

  // Create a New Conversation
  const handleNewChat = () => {
    const newId = Date.now().toString();
    const newChat: Conversation = {
      id: newId,
      title: 'New Conversation',
      date: 'Just now',
      active: true,
    };

    const initialWelcomeMessage: Message = {
      id: `m-${newId}`,
      sender: 'ai',
      text: "Hello! How can I assist you with your shopping queries today?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setConversations((prev) => [newChat, ...prev.map((c) => ({ ...c, active: false }))]);
    setMessagesMap((prev) => ({ ...prev, [newId]: [initialWelcomeMessage] }));
    setActiveChatId(newId);
  };

  // Send Message
  const handleSendMessage = (textToSend?: string) => {
    const query = textToSend || inputText;
    if (!query.trim()) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    // Auto-update title if it's new
    setConversations((prev) =>
      prev.map((c) => {
        if (c.id === activeChatId && c.title === 'New Conversation') {
          return { ...c, title: query.slice(0, 28) + (query.length > 28 ? '...' : '') };
        }
        return c;
      })
    );

    setMessagesMap((prev) => ({
      ...prev,
      [activeChatId]: [...(prev[activeChatId] || []), userMsg],
    }));

    setInputText('');
  };

  const currentMessages = messagesMap[activeChatId] || [];
  const currentChatTitle = conversations.find((c) => c.id === activeChatId)?.title || 'AI Product Assistant';

  return (
    <div className="h-screen bg-[#08080a] text-gray-200 flex flex-col font-sans overflow-hidden">
      {/* Top Header */}
      <Header activeTab="AI Chat" />

      {/* Main Grid View */}
      <div className="flex flex-1 overflow-hidden relative">
        
        {/* Collapsible Sidebar Wrapper */}
        <div
          className={`transition-all duration-300 ease-in-out flex shrink-0 ${
            isSidebarOpen ? 'w-72 opacity-100' : 'w-0 opacity-0 overflow-hidden pointer-events-none'
          }`}
        >
          <ChatSidebar
            conversations={conversations}
            onSelectConversation={handleSelectConversation}
            onNewChat={handleNewChat}
          />
        </div>

        {/* Chat Main Stream */}
        <main className="flex-1 flex flex-col justify-between bg-[#08080a] relative">
          
          {/* Top Sub-Header */}
          <div className="flex items-center gap-3 px-6 py-4 border-b border-gray-900/80 bg-[#08080a]">
            
            {/* Sidebar Toggle Button */}
            <button
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="text-gray-400 hover:text-white p-1 rounded-lg hover:bg-[#121217] transition-colors"
              title={isSidebarOpen ? 'Collapse sidebar' : 'Expand sidebar'}
            >
              {isSidebarOpen ? (
                <PanelLeftClose className="w-5 h-5" />
              ) : (
                <PanelLeft className="w-5 h-5" />
              )}
            </button>

            <div className="w-8 h-8 rounded-xl bg-purple-600/30 border border-purple-500/40 flex items-center justify-center text-purple-300">
              <Bot className="w-4 h-4" />
            </div>

            <div>
              <h3 className="text-sm font-bold text-white leading-tight">
                {currentChatTitle}
              </h3>
              <p className="text-[11px] text-gray-500 font-medium flex items-center gap-1.5 mt-0.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                GPT-5 + RAG + Qdrant
              </p>
            </div>
          </div>

          {/* Active Chat Conversation */}
          <div className="flex-1 overflow-y-auto px-6 py-8 flex flex-col items-center">
            <div className="w-full max-w-3xl flex flex-col gap-6">
              {currentMessages.map((msg) => (
                <ChatMessage key={msg.id} message={msg} />
              ))}
            </div>
          </div>

          {/* Suggestions & Input Section */}
          <div className="px-6 pb-4 pt-2 flex flex-col items-center w-full max-w-3xl mx-auto">
            <div className="flex flex-wrap justify-center gap-2 mb-4 w-full">
              {SUGGESTIONS.map((pill, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSendMessage(pill)}
                  className="px-4 py-2 rounded-xl bg-[#121217] border border-gray-800 text-gray-300 hover:text-white hover:border-gray-700 transition-all text-xs font-medium"
                >
                  {pill}
                </button>
              ))}
            </div>

            <div className="w-full relative">
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                rows={1}
                placeholder="Ask about your products... (Enter to send, Shift+Enter for newline)"
                className="w-full bg-[#121217] border border-gray-800/80 rounded-2xl py-4 pl-4 pr-12 text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all text-sm resize-none"
              />
              <button
                onClick={() => handleSendMessage()}
                className="absolute right-3 top-3 p-2 rounded-xl bg-[#1a1a24] text-gray-400 hover:text-white hover:bg-indigo-600 transition-all"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>

            <span className="text-[11px] text-gray-600 mt-3 font-medium">
              Powered by GPT-5 Turbo · RAG pipeline · Qdrant vector store
            </span>
          </div>

        </main>
      </div>
    </div>
  );
};